"""facedetection URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from facedetection.views import hello, current_datetime
from myapp import views as v
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', v.index),
    url(r'^post_create/$', v.post_create, name="post_create"),
    url(r'^post_detail/(?P<id>\d+)/$', v.post_detail, name="post_detail"),
    url(r'^users_list/$', v.users_list, name="users_list"),
    url(r'^post_update/$', v.post_update, name="post_update"),
    url(r'^post_delete/$', v.post_delete, name="post_delete"),
    url(r'^recognize_face/$', v.recognize_face, name="recognize_face"),
    url(r'^detect_face/$', v.detect_face, name="detect_face"),
    url(r'^face_recognition/$', v.face_recognition, name="face_recognition"),
    url(r'^face_detection/$', v.face_detection, name="face_detection"),
]

urlpatterns += staticfiles_urlpatterns()
