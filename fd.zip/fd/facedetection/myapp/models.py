from django.db import models

# Create your models here.
# User table Model
class Users(models.Model):
    id = models.AutoField(primary_key=True)
    emp_name = models.CharField(max_length=250)
    emp_id = models.CharField(unique=True, max_length=10)
    designation = models.CharField(max_length=100)
    created_on = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return self.emp_name

    def get_absolute_url(self):
        return self.id
