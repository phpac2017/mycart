"""facedetection URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from facedetection.views import hello, current_datetime
from myapp import views as v
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from . import 
from .views import {
    post_create,
    post_delete,
    post_detail,
    post_update,
    users_list,
    recognize_face,
    detect_face,
    face_recognition,
    face_detection,
}

urlpatterns = [
    #url(r'^create/$', "myapp.views.post_create"),
    url(r'^post_create/$', post_create),
    url(r'^post_detail/(?P<id>\d+)/$', post_detail, name="post_detail"),
    url(r'^users_list/$', users_list),
    url(r'^update/$', post_update),
    url(r'^delete/$', post_delete),
    url(r'^recognize_face/$', recognize_face),
    url(r'^detect_face/$', detect_face),
    url(r'^face_recognition/$', face_recognition),
    url(r'^face_detection/$', face_detection),
]

urlpatterns += staticfiles_urlpatterns()
