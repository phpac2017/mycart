from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.http import HttpResponse,StreamingHttpResponse, HttpResponseRedirect
from .models import Users
from .forms import faceRecognitionForm
from django.template import RequestContext
import cv2
import time
import os

size = 4

fn_dir = './att_faces'
(im_width, im_height) = (112, 92)
#fn_haar = "C:\\wamp64\\www\\facedetection\\xml\\haarcascade_frontalface_default.xml"

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
fn_haar  = PROJECT_ROOT + "\haarcascade_frontalface_default.xml"
#fn_haar = "haarcascade_frontalface_default.xml".format(base_path=os.path.abspath(os.path.dirname(__file__)))

emp_name = 'GV'

path = os.path.join(fn_dir, emp_name)
if not os.path.isdir(path):
    os.mkdir(path)

haar_cascade = cv2.CascadeClassifier(fn_haar)

# Create your views here.
def index(request):
    return render_to_response('index.html')

def post_create(request):
    form = faceRecognitionForm()
    # if request.method == "POST":
    #     print(request.POST)
    users = Users()
    users.emp_id = request.POST.get("emp_id")
    users.emp_name = request.POST.get("emp_name")
    users.designation = request.POST.get("designation")
    users.save()
    context = {
        "form" : form,
    }    
    return render(request, 'index.html', context)

def post_detail(request, id = None):
    
    instance = get_object_or_404(Users, id = id)
    context = {
        "instance" : instance,
        "title" : "Django Face Detection"
    }
    return render(request, 'post_detail.html', context)

def post_update(request):
    return HttpResponse("<h1>Update</h1>")

def post_delete(request):
    return HttpResponse("<h1>Delete</h1>")

def post_list(request):
    # if request.user.is_authenticated():
    #     context = {
    #         "title" : "Django Face Detection - Admin"
    #     }
    # else:
    #     context = {
    #         "title" : "Django Face Detection"
    #     }
    queryset = Users.objects.all()
    #List all the items from single record -> In view file use instance.
    # instance = get_object_or_404(Users, id = 2)
    # context = {
    #     "instance" : instance,
    #     "title" : "Django Face Detection"
    # }
    context = {
        "users_list" : queryset,
        "title" : "Django Face Detection"
    }
    return render(request, 'index.html', context)

class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        #set the width and height
        self.video.set(3,1280)
        self.video.set(4,1024)

    def get_frame(self):

        # Generate name for image file
        pin=sorted([int(n[:n.find('.')]) for n in os.listdir(path)
            if n[0]!='.' ]+[0])[-1] + 1

        # The program loops until it has 20 images of the face.
        count = 0
        pause = 0
        count_max = 20
        # The program loops until it has 20 images of the face.
        while count < count_max:
            ret,image = self.video.read()

            # Get image size
            height, width, channels = image.shape

            # Flip the image (optional)
            frame=cv2.flip(image,1,0)

            # Convert to grayscalel
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Resize to speed up detection (optinal, change size above)
            mini = cv2.resize(gray, (int(gray.shape[1] / size), int(gray.shape[0] / size)))

            # Detect faces and loop through each one
            faces = haar_cascade.detectMultiScale(mini)

            # We only consider largest face
            faces = sorted(faces, key=lambda x: x[3])

            # We only consider largest face
            faces = sorted(faces, key=lambda x: x[3])
            if faces:
                face_i = faces[0]
                (x, y, w, h) = [v * size for v in face_i]

                face = gray[y:y + h, x:x + w]
                face_resize = cv2.resize(face, (im_width, im_height))

                # Draw rectangle and write name
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 3)
                #cv2.putText(frame, emp_name, (x - 10, y - 10), cv2.FONT_HERSHEY_PLAIN,1,(0, 255, 0))
                
                if(pin <= 20):

                    # print("Saving training sample "+str(count+1)+"/"+str(count_max))
                    # print(pin)

                    # Save image file
                    cv2.imwrite('%s/%s.png' % (path, pin), face_resize)
                    pin += 1
                    count += 1
                    pause = 1

                
                ret,jpeg = cv2.imencode('.jpg',image)
                return jpeg.tobytes()

def gen(camera,seconds):
    start = time.time()
    time.clock()    
    elapsed = 0
    while elapsed < seconds:
        elapsed = time.time() - start
        print("loop cycle time: %f, seconds count: %02d" % (time.clock() , elapsed))        
        #stream(elapsed)
        #time.sleep(1)
        frame = camera.get_frame()
        yield (b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    #return redirect('https://www.google.com/')

def stream(request):
    # start = time.time()
    # time.clock()    
    # elapsed = 0
    # while elapsed < seconds:
    #     elapsed = time.time() - start
    #     print("loop cycle time: %f, seconds count: %02d" % (time.clock() , elapsed))
    # if seconds == 4:
    #     return redirect("https://www.google.com")     
    # else:
    return StreamingHttpResponse(gen(VideoCamera(),4),content_type="multipart/x-mixed-replace; boundary=frame")


    
    
    
    

