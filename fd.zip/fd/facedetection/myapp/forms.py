from django import forms
from .models import Users

class faceRecognitionForm(forms.ModelForm):
    class Meta:
        model = Users
        fields = ["emp_name","emp_id","designation"]

    def clean_emp_id(self):
        emp_id = self.cleaned_data.get('emp_id')
        return emp_id

    def clean_emp_name(self):
        emp_name = self.cleaned_data.get('emp_name')
        return emp_name

    def clean_designation(self):
        designation = self.cleaned_data.get('designation')
        return designation